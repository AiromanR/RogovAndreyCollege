﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind3_Rogov
{
    class VectorIn3D
    {
        private ArrayList startPoint;
        private ArrayList endPoint;
        public VectorIn3D(double x1, double x2, double x3,double y1, double y2, double y3)
        {
            ArrayList startPoint = new ArrayList { x1, x2, x3 };
            ArrayList endPoint = new ArrayList { y1, y2, y3 };
        }

        public ArrayList GetVector()
        {
            double x1 = (double)endPoint[0]; double x2 = (double)endPoint[1]; double x3 = (double)endPoint[2];
            double y1 = (double)startPoint[0]; double y2 = (double)startPoint[1]; double y3 = (double)startPoint[2];
            return new ArrayList{ x1 - y1, x2 - y2, x3 - y3};
        }
        public static ArrayList VectorSum(ArrayList Vec1, ArrayList Vec2)
        {
            ArrayList Sum = new ArrayList {(double)(Vec1[0]) + (double)(Vec2[0]),
                                           (double)(Vec1[1]) + (double)(Vec2[1]),
                                           (double)(Vec1[2]) + (double)(Vec2[2])};
            return Sum;
        }
        public static ArrayList VectorMinus(ArrayList Vec1, ArrayList Vec2)
        {
            ArrayList Minus = new ArrayList {(double)(Vec2[0]) - (double)(Vec1[0]),
                                           (double)(Vec2[1]) - (double)(Vec1[1]),
                                           (double)(Vec2[2]) - (double)(Vec1[2])};
            return Minus;
        }
        public static double VectorScalar(ArrayList Vec1, ArrayList Vec2)
        {
            //скаляр
            return(double)(Vec2[0]) * (double)(Vec1[0]) +
                  (double)(Vec2[1]) * (double)(Vec1[1])+
                  (double)(Vec2[2]) * (double)(Vec1[2]);
        }
        public static double VectorDlina(ArrayList Vec1)
        {
            double x = (double)Vec1[0];
            double y = (double)Vec1[1];
            double z = (double)Vec1[2];
            return Math.Sqrt(x * x + y * y + z * z);
        }
        public static double VectorCos(ArrayList Vec1, ArrayList Vec2)
        {

            return VectorScalar(Vec1, Vec2) / VectorDlina(Vec1) * VectorDlina(Vec2);
        }
    }
}

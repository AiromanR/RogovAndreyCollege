﻿using System;

namespace prKol_ind3_Rogov
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите координаты первого вектора построчно(x1, x2, x3, y1, y2, y3):");
            VectorIn3D vector1 = new VectorIn3D(Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()));
            Console.WriteLine("Введите координаты первого вектора построчно(x1, x2, x3, y1, y2, y3):");
            VectorIn3D vector2 = new VectorIn3D(Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()),
                                                Convert.ToDouble(Console.ReadLine()));
            while (true)
            {
                Console.WriteLine("Меню операций");
                Console.WriteLine("1. Найти сумму");
                Console.WriteLine("2. Найти разность");
                Console.WriteLine("3. Найти скалярное произведение");
                Console.WriteLine("4. Найти длину вектора");
                Console.WriteLine("5. Найти кисонус угла между векторами");
                Console.WriteLine("5. Стоп");
                Console.WriteLine("6. Стоп");

                string vibor = Console.ReadLine();
                if (vibor == "6") break;

                switch (vibor)
                {

                    case "1":
                        Console.WriteLine("Сумма векторов: ");
                        Console.WriteLine(VectorIn3D.VectorSum(vector1.GetVector(), vector2.GetVector()));
                        break;
                    case "2":
                        Console.WriteLine("Разность векторов: ");
                        Console.WriteLine(VectorIn3D.VectorMinus(vector1.GetVector(), vector2.GetVector()));
                        break;
                    case "3":
                        Console.WriteLine("Скалярное векторов: ");
                        Console.WriteLine(VectorIn3D.VectorScalar(vector1.GetVector(), vector2.GetVector()));
                        break;
                    case "4":
                        Console.WriteLine("Длины векторов: ");
                        Console.WriteLine(VectorIn3D.VectorDlina(vector1.GetVector()));
                        Console.WriteLine(VectorIn3D.VectorDlina(vector2.GetVector()));
                        break;
                    case "5":
                        Console.WriteLine("Косинус векторов: ");
                        Console.WriteLine(VectorIn3D.VectorCos(vector1.GetVector(), vector2.GetVector()));
                        break;

                }
            }
        }
    }
}
